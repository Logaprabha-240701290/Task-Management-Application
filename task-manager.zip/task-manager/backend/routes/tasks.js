const express = require('express');
const Task = require('../models/Task');
const { protect } = require('../middleware/auth');

const router = express.Router();

// All routes are protected
router.use(protect);

// @GET /api/tasks - Get all tasks for current user
router.get('/', async (req, res) => {
  try {
    const { status, priority, search, sort = '-createdAt' } = req.query;

    const query = { user: req.user._id };

    if (status && status !== 'all') query.status = status;
    if (priority && priority !== 'all') query.priority = priority;
    if (search) {
      query.$or = [
        { title: { $regex: search, $options: 'i' } },
        { description: { $regex: search, $options: 'i' } },
      ];
    }

    const tasks = await Task.find(query).sort(sort);

    const stats = {
      total: await Task.countDocuments({ user: req.user._id }),
      todo: await Task.countDocuments({ user: req.user._id, status: 'todo' }),
      inProgress: await Task.countDocuments({ user: req.user._id, status: 'in-progress' }),
      completed: await Task.countDocuments({ user: req.user._id, status: 'completed' }),
    };

    res.json({ tasks, stats });
  } catch (error) {
    res.status(500).json({ message: 'Failed to fetch tasks.' });
  }
});

// @GET /api/tasks/:id - Get single task
router.get('/:id', async (req, res) => {
  try {
    const task = await Task.findOne({ _id: req.params.id, user: req.user._id });
    if (!task) return res.status(404).json({ message: 'Task not found.' });
    res.json({ task });
  } catch (error) {
    res.status(500).json({ message: 'Failed to fetch task.' });
  }
});

// @POST /api/tasks - Create task
router.post('/', async (req, res) => {
  try {
    const { title, description, status, priority, dueDate, tags } = req.body;

    const task = await Task.create({
      title,
      description,
      status,
      priority,
      dueDate,
      tags,
      user: req.user._id,
    });

    // Emit real-time update
    req.io.to(req.user._id.toString()).emit('task-created', task);

    res.status(201).json({ message: 'Task created.', task });
  } catch (error) {
    if (error.name === 'ValidationError') {
      const messages = Object.values(error.errors).map((e) => e.message);
      return res.status(400).json({ message: messages[0] });
    }
    res.status(500).json({ message: 'Failed to create task.' });
  }
});

// @PUT /api/tasks/:id - Update task
router.put('/:id', async (req, res) => {
  try {
    const task = await Task.findOneAndUpdate(
      { _id: req.params.id, user: req.user._id },
      req.body,
      { new: true, runValidators: true }
    );

    if (!task) return res.status(404).json({ message: 'Task not found.' });

    // Emit real-time update
    req.io.to(req.user._id.toString()).emit('task-updated', task);

    res.json({ message: 'Task updated.', task });
  } catch (error) {
    if (error.name === 'ValidationError') {
      const messages = Object.values(error.errors).map((e) => e.message);
      return res.status(400).json({ message: messages[0] });
    }
    res.status(500).json({ message: 'Failed to update task.' });
  }
});

// @DELETE /api/tasks/:id - Delete task
router.delete('/:id', async (req, res) => {
  try {
    const task = await Task.findOneAndDelete({ _id: req.params.id, user: req.user._id });
    if (!task) return res.status(404).json({ message: 'Task not found.' });

    // Emit real-time update
    req.io.to(req.user._id.toString()).emit('task-deleted', req.params.id);

    res.json({ message: 'Task deleted.' });
  } catch (error) {
    res.status(500).json({ message: 'Failed to delete task.' });
  }
});

// @PATCH /api/tasks/:id/status - Quick status update
router.patch('/:id/status', async (req, res) => {
  try {
    const { status } = req.body;
    const task = await Task.findOneAndUpdate(
      { _id: req.params.id, user: req.user._id },
      { status },
      { new: true }
    );

    if (!task) return res.status(404).json({ message: 'Task not found.' });

    req.io.to(req.user._id.toString()).emit('task-updated', task);
    res.json({ message: 'Status updated.', task });
  } catch (error) {
    res.status(500).json({ message: 'Failed to update status.' });
  }
});

module.exports = router;
