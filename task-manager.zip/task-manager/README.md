# ✦ TaskFlow — Task Management Application

A full-stack task management web application built with React, Node.js/Express, MongoDB, and Socket.io for real-time updates.

---

## 🚀 Tech Stack

| Layer | Tech |
|---|---|
| Frontend | React 18, React Router v6, Axios, Socket.io-client |
| Backend | Node.js, Express.js, Socket.io |
| Database | MongoDB + Mongoose |
| Auth | JWT + bcryptjs |
| Real-time | WebSockets via Socket.io |

---

## 📁 Project Structure

```
task-manager/
├── backend/
│   ├── models/         # Mongoose schemas (User, Task)
│   ├── routes/         # Express route handlers (auth, tasks)
│   ├── middleware/     # JWT auth middleware
│   ├── server.js       # Entry point + Socket.io setup
│   └── .env.example    # Environment variable template
├── frontend/
│   ├── public/
│   └── src/
│       ├── components/ # TaskCard, TaskModal, ConfirmModal
│       ├── context/    # AuthContext (global auth state)
│       ├── hooks/      # useSocket (real-time updates)
│       ├── pages/      # LoginPage, RegisterPage, DashboardPage
│       └── utils/      # Axios instance with interceptors
└── package.json        # Root scripts with concurrently
```

---

## ⚙️ Setup Instructions

### Prerequisites
- Node.js 16+
- MongoDB (local) or MongoDB Atlas (cloud)

### 1. Clone / open in VS Code
```bash
cd task-manager
```

### 2. Set up environment variables
```bash
cp backend/.env.example backend/.env
```
Edit `backend/.env`:
```
PORT=5000
MONGODB_URI=mongodb://localhost:27017/taskmanager
JWT_SECRET=change_this_to_a_long_random_string
CLIENT_URL=http://localhost:3000
```

### 3. Install all dependencies
```bash
npm install                    # root (installs concurrently)
npm install --prefix backend   # backend deps
npm install --prefix frontend  # frontend deps
```
Or use the helper script:
```bash
npm run install:all
```

### 4. Start both servers
```bash
npm run dev
```
This runs backend on **http://localhost:5000** and frontend on **http://localhost:3000** simultaneously.

---

## 🔑 API Endpoints

### Auth
| Method | Endpoint | Description |
|---|---|---|
| POST | `/api/auth/register` | Create account |
| POST | `/api/auth/login` | Sign in |
| GET | `/api/auth/me` | Get current user |

### Tasks (all protected — requires Bearer token)
| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/tasks` | Get all tasks (filter by status, priority, search) |
| POST | `/api/tasks` | Create task |
| PUT | `/api/tasks/:id` | Update task |
| DELETE | `/api/tasks/:id` | Delete task |
| PATCH | `/api/tasks/:id/status` | Quick status update |

---

## ✨ Features

- **User Auth** — Register/login with JWT, tokens persisted in localStorage
- **CRUD Tasks** — Create, read, update, delete with full validation
- **Status Tracking** — todo → in-progress → completed (click badge to cycle)
- **Priority Levels** — High / Medium / Low with color-coded left border
- **Due Dates** — Overdue detection with visual alert
- **Tags** — Comma-separated tags on each task
- **Real-time** — WebSocket updates via Socket.io (changes appear instantly)
- **Search & Filter** — Live search + filter by status and priority
- **Skeleton Loading** — Smooth loading states
- **Responsive** — Mobile-first design, works on all screen sizes
- **Dark Theme** — Purple/teal accent dark UI

---

## 🛠 VS Code Tips

Install recommended extensions:
- **ESLint** — code linting
- **Prettier** — code formatting
- **MongoDB for VS Code** — browse your database
- **Thunder Client** — test API endpoints

---

## 📝 Submission Notes

- Full-stack architecture: React frontend + Express REST API + MongoDB
- JWT-based authentication with bcryptjs password hashing
- Real-time updates using WebSockets (Socket.io) — satisfies the optional requirement
- Fully responsive for web and mobile screens
- All CRUD operations for tasks implemented
