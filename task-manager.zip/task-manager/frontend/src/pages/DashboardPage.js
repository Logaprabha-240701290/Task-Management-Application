import React, { useState, useEffect, useCallback } from 'react';
import toast from 'react-hot-toast';
import { useAuth } from '../context/AuthContext';
import { useSocket } from '../hooks/useSocket';
import api from '../utils/api';
import TaskCard from '../components/TaskCard';
import TaskModal from '../components/TaskModal';
import ConfirmModal from '../components/ConfirmModal';

const STATUS_TABS = [
  { value: 'all', label: 'All' },
  { value: 'todo', label: 'To Do' },
  { value: 'in-progress', label: 'In Progress' },
  { value: 'completed', label: 'Completed' },
];

export default function DashboardPage() {
  const { user, logout } = useAuth();
  const [tasks, setTasks] = useState([]);
  const [stats, setStats] = useState({ total: 0, todo: 0, inProgress: 0, completed: 0 });
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('all');
  const [search, setSearch] = useState('');
  const [priority, setPriority] = useState('all');
  const [showModal, setShowModal] = useState(false);
  const [editTask, setEditTask] = useState(null);
  const [deleteTarget, setDeleteTarget] = useState(null);

  const fetchTasks = useCallback(async () => {
    setLoading(true);
    try {
      const params = {};
      if (activeTab !== 'all') params.status = activeTab;
      if (priority !== 'all') params.priority = priority;
      if (search.trim()) params.search = search.trim();
      const res = await api.get('/tasks', { params });
      setTasks(res.data.tasks);
      setStats(res.data.stats);
    } catch {
      toast.error('Failed to load tasks.');
    } finally {
      setLoading(false);
    }
  }, [activeTab, priority, search]);

  useEffect(() => {
    const debounce = setTimeout(fetchTasks, 300);
    return () => clearTimeout(debounce);
  }, [fetchTasks]);

  // Real-time socket handlers
  const handleSocketCreate = useCallback((task) => {
    setTasks((prev) => [task, ...prev]);
    setStats((s) => ({ ...s, total: s.total + 1, [task.status === 'todo' ? 'todo' : task.status === 'in-progress' ? 'inProgress' : 'completed']: s[task.status === 'todo' ? 'todo' : task.status === 'in-progress' ? 'inProgress' : 'completed'] + 1 }));
  }, []);

  const handleSocketUpdate = useCallback((task) => {
    setTasks((prev) => prev.map((t) => t._id === task._id ? task : t));
  }, []);

  const handleSocketDelete = useCallback((taskId) => {
    setTasks((prev) => prev.filter((t) => t._id !== taskId));
  }, []);

  useSocket(handleSocketCreate, handleSocketUpdate, handleSocketDelete);

  const handleCreateOrUpdate = async (formData) => {
    try {
      if (editTask) {
        await api.put(`/tasks/${editTask._id}`, formData);
        toast.success('Task updated.');
      } else {
        await api.post('/tasks', formData);
        toast.success('Task created.');
      }
      setShowModal(false);
      setEditTask(null);
      fetchTasks();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Something went wrong.');
    }
  };

  const handleStatusChange = async (taskId, newStatus) => {
    try {
      await api.patch(`/tasks/${taskId}/status`, { status: newStatus });
      fetchTasks();
    } catch {
      toast.error('Failed to update status.');
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    try {
      await api.delete(`/tasks/${deleteTarget._id}`);
      toast.success('Task deleted.');
      setDeleteTarget(null);
      fetchTasks();
    } catch {
      toast.error('Failed to delete task.');
    }
  };

  const openEdit = (task) => {
    setEditTask(task);
    setShowModal(true);
  };

  const openCreate = () => {
    setEditTask(null);
    setShowModal(true);
  };

  const initials = user?.name?.split(' ').map((n) => n[0]).join('').toUpperCase().slice(0, 2) || 'U';

  return (
    <div className="dashboard">
      {/* Navbar */}
      <nav className="navbar">
        <span className="navbar-brand">✦ TaskFlow</span>
        <div className="navbar-right">
          <div className="user-badge">
            <div className="avatar">{initials}</div>
            <span>{user?.name}</span>
          </div>
          <button className="btn btn-ghost btn-sm" onClick={logout}>Sign out</button>
        </div>
      </nav>

      <main className="dashboard-main">
        {/* Stats */}
        <div className="stats-grid">
          <StatCard icon="📋" label="Total Tasks" value={stats.total} color="#89b4fa" />
          <StatCard icon="⭕" label="To Do" value={stats.todo} color="#cba6f7" />
          <StatCard icon="🔄" label="In Progress" value={stats.inProgress} color="#f9e2af" />
          <StatCard icon="✅" label="Completed" value={stats.completed} color="#a6e3a1" />
        </div>

        {/* Status tabs */}
        <div className="status-tabs">
          {STATUS_TABS.map((tab) => (
            <button
              key={tab.value}
              className={`status-tab ${activeTab === tab.value ? 'active' : ''}`}
              onClick={() => setActiveTab(tab.value)}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Controls */}
        <div className="controls-bar">
          <div className="search-input-wrap">
            <span className="search-icon">🔍</span>
            <input
              type="text"
              placeholder="Search tasks…"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <select className="filter-select" value={priority} onChange={(e) => setPriority(e.target.value)}>
            <option value="all">All priorities</option>
            <option value="high">High</option>
            <option value="medium">Medium</option>
            <option value="low">Low</option>
          </select>
          <button className="btn btn-primary" style={{ width: 'auto' }} onClick={openCreate}>
            + New Task
          </button>
        </div>

        {/* Task grid */}
        <div className="tasks-grid">
          {loading ? (
            Array.from({ length: 6 }).map((_, i) => <SkeletonCard key={i} />)
          ) : tasks.length === 0 ? (
            <div className="empty-state">
              <div className="empty-state-icon">📭</div>
              <h3>No tasks found</h3>
              <p>{search ? 'Try a different search.' : 'Create your first task to get started.'}</p>
            </div>
          ) : (
            tasks.map((task) => (
              <TaskCard
                key={task._id}
                task={task}
                onEdit={() => openEdit(task)}
                onDelete={() => setDeleteTarget(task)}
                onStatusChange={handleStatusChange}
              />
            ))
          )}
        </div>
      </main>

      {showModal && (
        <TaskModal
          task={editTask}
          onClose={() => { setShowModal(false); setEditTask(null); }}
          onSave={handleCreateOrUpdate}
        />
      )}

      {deleteTarget && (
        <ConfirmModal
          title="Delete task?"
          message={`"${deleteTarget.title}" will be permanently deleted.`}
          onConfirm={handleDelete}
          onCancel={() => setDeleteTarget(null)}
        />
      )}
    </div>
  );
}

function StatCard({ icon, label, value, color }) {
  return (
    <div className="stat-card">
      <div className="stat-icon" style={{ background: `${color}22` }}>
        <span style={{ fontSize: '1.2rem' }}>{icon}</span>
      </div>
      <div className="stat-info">
        <div className="stat-value" style={{ color }}>{value}</div>
        <div className="stat-label">{label}</div>
      </div>
    </div>
  );
}

function SkeletonCard() {
  return (
    <div className="task-card" style={{ gap: '0.75rem', cursor: 'default' }}>
      <div className="skeleton" style={{ height: 18, width: '70%' }} />
      <div className="skeleton" style={{ height: 14, width: '90%' }} />
      <div className="skeleton" style={{ height: 14, width: '60%' }} />
      <div style={{ display: 'flex', gap: '0.5rem' }}>
        <div className="skeleton" style={{ height: 22, width: 70, borderRadius: 20 }} />
        <div className="skeleton" style={{ height: 22, width: 55, borderRadius: 20 }} />
      </div>
    </div>
  );
}
