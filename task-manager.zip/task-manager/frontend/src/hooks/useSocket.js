import { useEffect, useRef } from 'react';
import { io } from 'socket.io-client';
import { useAuth } from '../context/AuthContext';

export function useSocket(onTaskCreated, onTaskUpdated, onTaskDeleted) {
  const { user } = useAuth();
  const socketRef = useRef(null);

  useEffect(() => {
    if (!user) return;

    socketRef.current = io('http://localhost:5000', {
      transports: ['websocket'],
    });

    socketRef.current.emit('join-room', user._id);

    socketRef.current.on('task-created', (task) => {
      onTaskCreated && onTaskCreated(task);
    });
    socketRef.current.on('task-updated', (task) => {
      onTaskUpdated && onTaskUpdated(task);
    });
    socketRef.current.on('task-deleted', (taskId) => {
      onTaskDeleted && onTaskDeleted(taskId);
    });

    return () => {
      socketRef.current?.disconnect();
    };
  }, [user]); // eslint-disable-line

  return socketRef.current;
}
