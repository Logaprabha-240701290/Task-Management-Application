import React from 'react';
import { format, isPast, isToday } from 'date-fns';

const STATUS_OPTIONS = ['todo', 'in-progress', 'completed'];

export default function TaskCard({ task, onEdit, onDelete, onStatusChange }) {
  const isOverdue = task.dueDate && isPast(new Date(task.dueDate)) && task.status !== 'completed';
  const isDueToday = task.dueDate && isToday(new Date(task.dueDate));

  const cycleStatus = (e) => {
    e.stopPropagation();
    const idx = STATUS_OPTIONS.indexOf(task.status);
    const next = STATUS_OPTIONS[(idx + 1) % STATUS_OPTIONS.length];
    onStatusChange(task._id, next);
  };

  return (
    <div
      className={`task-card priority-${task.priority}`}
      onClick={onEdit}
    >
      <div className="task-card-header">
        <span className={`task-title ${task.status === 'completed' ? 'completed' : ''}`}>
          {task.title}
        </span>
        <div className="task-actions">
          <button
            className="btn btn-ghost btn-icon"
            title="Edit"
            onClick={(e) => { e.stopPropagation(); onEdit(); }}
          >✏️</button>
          <button
            className="btn btn-ghost btn-icon"
            title="Delete"
            onClick={(e) => { e.stopPropagation(); onDelete(); }}
          >🗑️</button>
        </div>
      </div>

      {task.description && (
        <p className="task-description">{task.description}</p>
      )}

      <div className="task-meta">
        <button
          className={`badge badge-${task.status}`}
          style={{ cursor: 'pointer', border: 'none' }}
          title="Click to cycle status"
          onClick={cycleStatus}
        >
          {task.status === 'todo' && '⭕'}
          {task.status === 'in-progress' && '🔄'}
          {task.status === 'completed' && '✅'}
          {' '}{task.status.replace('-', ' ')}
        </button>

        <span className={`badge badge-${task.priority}`}>
          {task.priority === 'high' && '🔴'}
          {task.priority === 'medium' && '🟡'}
          {task.priority === 'low' && '🟢'}
          {' '}{task.priority}
        </span>

        {task.dueDate && (
          <span className={`due-date ${isOverdue ? 'overdue' : ''}`}>
            📅 {isDueToday ? 'Today' : format(new Date(task.dueDate), 'MMM d')}
            {isOverdue && ' (Overdue)'}
          </span>
        )}
      </div>

      {task.tags?.length > 0 && (
        <div className="tags">
          {task.tags.slice(0, 3).map((tag, i) => (
            <span key={i} className="tag">#{tag}</span>
          ))}
          {task.tags.length > 3 && <span className="tag">+{task.tags.length - 3}</span>}
        </div>
      )}
    </div>
  );
}
